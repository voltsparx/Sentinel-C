# Sentinel-C v4.0 (Windows x86_64)

Author: voltsparx
Contact: voltsparx@gmail.com

Contents:
- bin/sentinel-c.exe
- docs/
- Usage.txt
- LICENSE
- SHA256SUMS.txt

Quick Run (PowerShell):
.\bin\sentinel-c.exe --help
.\bin\sentinel-c.exe --prompt-mode
