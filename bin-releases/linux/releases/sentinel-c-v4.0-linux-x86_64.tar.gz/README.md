# Sentinel-C v4.0 (Linux x86_64)

Author: voltsparx
Contact: voltsparx@gmail.com

Contents:
- bin/sentinel-c
- docs/
- Usage.txt
- LICENSE
- SHA256SUMS.txt

Quick Run:
chmod +x bin/sentinel-c
./bin/sentinel-c --help
./bin/sentinel-c --prompt-mode
